<?PHP 
ini_set('default_charset','utf-8');
$var = " ";
$result = " ";
$calc='MF';

if(isset($_POST['CALCULAR'])){
    $var = (string)$_POST['var'];
    $calc = $_POST['CALCULAR'];
    
    if($var == "M"){
        $result = " M - Masculino";
    }
    elseif($var == "F"){
        $result = " F - Feminino";
    }
    else{
        $result = "Sexo inválido";
    }
}



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>SEXOS</title>
</head>
<body>
    
    <form method="post">
        <p>DIGITE UM NÚMERO</p> <br>
        <input name="var" value= <?= $var ?> required> <br>
        <input type="submit" name="CALCULAR" value="CALCULAR">
       <br><br>
       
        
        <p><?= $result ?> </p><br>
    
    </form>

</body>
</html>