<?PHP 
ini_set('default_charset','utf-8');
$n1 = 0;
$result = " ";
$calc='par';

if(isset($_POST['CALCULAR'])){
    $n1 = (int)$_POST['n1'];
    $calc = $_POST['CALCULAR'];
    
    if($n1>=0){
        $result = " O número é positivo";
    }
    else{
        $result = " O número é negativo";
    }
}



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>NÚMERO MAIOR</title>
</head>
<body>
    
    <form method="post">
        <p>DIGITE UM NÚMERO</p> <br>
        <input type="number" name="n1" value= <?= $n1 ?> required > <br>
        <input type="submit" name="CALCULAR" value="CALCULAR">
       <br><br>
       
        
        <p>Ele é: <?= $result ?> </p><br>
    
    </form>

</body>
</html>