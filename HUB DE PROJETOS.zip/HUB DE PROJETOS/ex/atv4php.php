<?php
ini_set('default_charset','utf-8');
    $n1 = 0;
    $n2 = 0;
    $result = " ";
   

    if(isset($_POST['CALCULAR'])){
        $n1 = (int)$_POST['n1'];
        $n2 = (int)$_POST['n2'];
    

        $media= ($n1+$n2)/2;

        if($media==10){
            $result = "APROVADO COM DISTINÇÃO";    
        }

        elseif($media<7){
            $result = "REPROVADO";    
        }
        elseif($media>=7){
            $result = "APROVADO";    
        }
    }

?> 
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
    <form method="post">
        <p></p>
        NOTA 1: <br>
        <input type="number" name="n1" value= <?= $n1 ?> required> <br>
        NOTA 2:  <br>
        <input type="number" name="n2" value= <?= $n2 ?> required> <br>
        <input type="submit" name="CALCULAR" value="CALCULAR">
        <br><br>
        
        <p>O aluno está: <?= $result ?> </p><br>
    
    </form>

</body>
</html>