<div class="titulo">Tipo Inteiro</div>

<?php
ini_set('default_charset','utf-8');
    
    echo 11;  
    echo '<br>';

    var_dump(11);
    echo "<br>";

    echo PHP_INT_MAX, '<br>';
    echo PHP_INT_MIN, '<br>';
    echo "<p>separacao</p>";
    echo 027, '<br>'; //Base octal
    echo 0b11001, '<br>'; //Base binaria
    echo 0x1cf0, '<br>'; //Base hexadecimal




?>