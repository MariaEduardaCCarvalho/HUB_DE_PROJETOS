<?PHP 
ini_set('default_charset','utf-8');
$n1 = 0.0;
$n2 = 0.0;
$n3 = 0.0;
$result = " ";

if(isset($_POST['CALCULAR'])){
    $n1 = (float)$_POST['n1'];
    $n2 = (float)$_POST['n2'];
    $n3 = (float)$_POST['n3'];
    
    if(($n1<$n2)&&($n1<$n3)){
        $result = " O segundo número é o menor.";
    }
    elseif(($n1>$n2)&&($n3>$n2)){
        $result = " O segundo número é o menor.";
    }
    elseif(($n1>$n3)&&($n2>$n3)){
        $result = " O terceiro número é o menor";
    }

}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>NÚMERO MAIOR</title>
</head>
<body>
    
    <form method="post">
        <p>DIGITE TRÊS PREÇOS</p>
        Primeiro preço:<br>
        <input type="number" name="n1" value= <?= $n1 ?> required > <br>
        Segundo preço:<br>
        <input type="number" name="n2" value= <?= $n2 ?> required  > <br>
        Terceiro preço:<br>
        <input type="number" name="n3" value= <?= $n3 ?> required  > <br>
        <input type="submit" name="CALCULAR" value="CALCULAR">
       <br><br>
       
        
        <p>O menor deles é: <?= $result ?> </p><br>
    
    </form>

</body>
</html>