<?PHP 
ini_set('default_charset','utf-8');
$n1 = 0;
$n2 = 0;
$result = " ";
$calc='maior';

if(isset($_POST['CALCULAR'])){
    $n1 = (int)$_POST['n1'];
    $n2 = (int)$_POST['n2'];
    $calc = $_POST['CALCULAR'];
    
    if($n1>$n2){
        $result = " O primeiro número é o maior";
    }
    elseif($n1<$n2){
        $result = " O segundo número é o maior";
    }
    else{
        $result = " Os valores são iguais";
    }
}



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>NÚMERO MAIOR</title>
</head>
<body>
    
    <form method="post">
        <p>DIGITE DOIS NÚMEROS</p>
        Primeiro numero <br>
        <input type="number" name="n1" value= <?= $n1 ?> required > <br>
        Segundo numero  <br>
        <input type="number" name="n2" value= <?= $n2 ?> required  > <br>
        <input type="submit" name="CALCULAR" value="CALCULAR">
       <br><br>
       
        
        <p>O maior deles é: <?= $result ?> </p><br>
    
    </form>

</body>
</html>