<div class="titulo">Tipo float</div>

<?php

    echo 1.1, '<br>';

    var_dump(1.0);
    echo '<br>';

    echo PHP_FLOAT_MAX, '<br>';
    echo PHP_FLOAT_MIN, '<br>';
    echo 1.2e3, '<br>'; // 1.2 elevado a 10 vezes 3 = 1200
    echo 0.5E-3, '<br>'; // 1.3 elevado a 10 vezes -3 = 0.0013
?>